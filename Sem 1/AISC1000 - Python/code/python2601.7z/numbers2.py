import math
x = 40 + 11
y = math.log10 (100)
print (" x is: ",x," y is: ",y)
print ("min(x, y, 1000) : ", min(x,y , 1000))
print ("sin(30) : ",  math.sin(30))
print ("cos(30) : ",  math.cos(30))
print ("max(-20, 100, 400) : ", max(-20, 100, 400))
print ("min(0, 100, -400) : ", min(0, 100, -400))
print ("math.log10(math.pi) : ", math.log10(math.pi))
print ("round(70.23456) : ", round(70.23456))
print ("round(56.659,1) : ", round(56.659,1))
print ("round(80.264, 2) : ", round(80.264, 2))
print ("math.sqrt(100) : ", math.sqrt(100))
print ("math.modf(math.pi) : ", math.modf(math.pi))#modf returns the fractional and integer parts