p = float(input("Enter the first float: "))
q = float(input("Enter the second float: "))
sumFloat = p + q
print('The sum of the two float number', p, ' and ', q, ' is ', sumFloat, '.', sep='')