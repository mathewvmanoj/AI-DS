import math
num1 = int (input("Enter a number: "))
num2 = int (input("Enter a second number: "))
print('The sum of ', num1, ' and ', num2, ' is ', num1+num2, '.', sep='')
print ('the exp of num1 to num2:', num1**num2)
print ('the exp of num1 to num2:', num1**num2)
print (math.floor(num1))
print (math.fabs(num1))
print (abs(num1))
