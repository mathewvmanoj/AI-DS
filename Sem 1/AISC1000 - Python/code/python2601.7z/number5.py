a = 21
b = 10
c = 0

c = a + b
print ("Value of c is ", c)

c = a - b
print ("Value of c is ", c )

c = a * b
print ("Value of c is ", c)

c = a / b
print ("Value of c is ", c )

c = a % b
print ("Value of c is ", c)

a = 2
b = 3
c = a**b 
print ("Value of c is ", c)

a = 10
b = 5
c = a//b #floor division, the result is the quotient only
print ("Value of c is ", c)
a, b= -10, 4
c = a//b #floor division, if one operand is negaive, the result is rounded away from zero
print("Value of c is ", c)

a = 4
b = 19
c = 30
c *= a
print ('Value of c is: ', c)
c %= a
print ('Value of c is: ', c)
c //= a
print ('Value of c is: ', c)
