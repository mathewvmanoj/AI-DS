import random
print ("returns a random number from range(100) : ",random.choice(range(100)))
print ("returns random element from list [1, 2, 3, 5, 9]) : ", random.choice([1, 5, 3, 5, 9, 'll']))
print ("returns random character from string 'Hello World' : ", random.choice('Hello World'))
print (random.random())
print ("Random Float uniform 10<= r <15) : ",  random.uniform(10, 15))
#tup1 = ('physics', 'chemistry', 1997, 2000)
#print (random.choice(tup1))
