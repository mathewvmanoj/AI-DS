myDict1 = {}
myDict1['ibm']='12345'
myDict1['ibm-x']='23098'
myDict1['hp']='28764'
myDict1['dell']='09416'
myDict1['asus']='99880'
#myDict1={
print (myDict1)
print ('the value of ibm is: ',myDict1['ibm'])
del myDict1['hp']
print (myDict1)
myDict1.clear()
print (myDict1)
#del myDict1
#print (myDict1)
myDict1['lenovo']='11221'
print (myDict1)