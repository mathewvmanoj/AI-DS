myDict = {('empName'): 'John', 'title':'Director', 'yOfEmp':8, 'title':'Assisstant'}
print (myDict[('empName')])
print(myDict.get(('empName')))
print (myDict.get('title'))