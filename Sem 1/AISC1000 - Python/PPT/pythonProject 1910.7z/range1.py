for i in range(1,11):

    for i in range(1, 11):
        print ()
    if (i == 5):
        break
    print(i, end='')
    print()